# ATLAS — World Discovery

Buscador interactivo de países desarrollado para la práctica P1: Consumir una API REST pública con `fetch`.

## Tecnologías
- HTML5
- CSS3 (Grid, Flexbox, responsive design, animaciones)
- JavaScript (fetch, async/await, DOM)
- REST Countries API v5 (migración por obsolescencia de v3.1)

## Ejecutar en Visual Studio Code
1. Descarga o clona este repositorio.
2. Abre la carpeta `ATLAS_Paises` en Visual Studio Code.
3. Instala la extensión **Live Server**.
4. Haz clic derecho en `index.html` y selecciona **Open with Live Server**.
5. Se abrirá la página en el navegador. La conexión a internet es necesaria para consultar la API, cargar las imágenes remotas y Google Fonts.

## Funcionalidades
- Búsqueda de países por nombre.
- Tarjetas con bandera, nombre, capital, región y población.
- Filtro por región mediante `/region/{region}`.
- Orden por nombre y población ascendente/descendente.
- Modal de detalles con idiomas, monedas, superficie, zona horaria y enlace a Google Maps.
- Manejo de errores HTTP, país no encontrado y problemas de conexión.
- Diseño adaptable a móvil y escritorio.

## API
`https://api.restcountries.com/countries/v5`

Ejemplo:
`https://api.restcountries.com/countries/v5/name?q=mexico` (requiere encabezado Authorization: Bearer)

## Estructura
- `index.html`: estructura y contenido.
- `styles.css`: identidad visual y diseño responsive.
- `app.js`: consumo de API, filtros, ordenamiento y modal.
- `DOCUMENTACION_P1.docx`: respuestas, explicación y guía de evidencias.

## Evidencias que debes generar
Consulta `DOCUMENTACION_P1.docx`. Las capturas deben tomarse en tu propio navegador:
1. Búsqueda correcta (por ejemplo, México).
2. País inexistente (por ejemplo, Narnia).
3. Error sin conexión (DevTools > Network > Offline).
4. DevTools > Network con la petición seleccionada y los datos anotados.

## GitHub
Los comandos para publicar el proyecto están explicados en la documentación. Recuerda sustituir `TU_USUARIO` por tu nombre de usuario de GitHub.


## Nota de compatibilidad (noviembre de 2026)
La API v3.1 indicada en la guía original está obsoleta. Esta versión del proyecto se migró a v5. La clave `rc_live_demo` es una clave pública de demostración; para uso estable crea una clave propia y autoriza el hostname `localhost` o `127.0.0.1` en Allowed origins. No publiques una clave privada en JavaScript del navegador. Consulta https://restcountries.com/docs/countries.

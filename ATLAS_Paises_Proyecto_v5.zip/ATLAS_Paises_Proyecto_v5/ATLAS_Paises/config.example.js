// Copia este archivo y nombra la copia: config.js
// Pega tu clave personal de REST Countries. No subas config.js a GitHub.
window.ATLAS_API_KEY = "rc_live_be8878d10b464481bc40b0990ca28a63";

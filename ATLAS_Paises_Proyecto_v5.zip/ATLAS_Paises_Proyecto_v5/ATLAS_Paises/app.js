// ATLAS — adaptación a REST Countries API v5 (noviembre 2026)
// La API v3.1 del PDF está obsoleta. v5 requiere clave y usa otro formato JSON.
const API = "https://api.restcountries.com/countries/v5";
const API_KEY = "rc_live_be8878d10b464481bc40b0990ca28a63"; // Clave demo pública para pruebas; no usar claves privadas en frontend.
const CAMPOS = "names.common,names.official,codes.alpha_2,codes.alpha_3,region,subregion,population,capitals,languages,currencies,timezones,continents,area.kilometers";

const form = document.getElementById("formBuscar");
const input = document.getElementById("txtPais");
const mensaje = document.getElementById("mensaje");
const resultados = document.getElementById("results");
const regionSelect = document.getElementById("regionSelect");
const sortSelect = document.getElementById("sortSelect");
const resultCount = document.getElementById("resultCount");
const clearButton = document.getElementById("clearButton");
const modal = document.getElementById("detailModal");
const modalContent = document.getElementById("modalContent");
let paisesActuales = [];

function setMensaje(texto, tipo = "") {
  mensaje.textContent = texto;
  mensaje.className = `message ${tipo}`;
}
function urlConCampos(url) {
  return `${url}${url.includes("?") ? "&" : "?"}response_fields=${encodeURIComponent(CAMPOS)}&limit=100`;
}
async function solicitar(url) {
  let respuesta;
  try {
    respuesta = await fetch(urlConCampos(url), {
      method: "GET",
      headers: { "Authorization": `Bearer ${API_KEY}`, "Accept": "application/json" }
    });
  } catch {
    throw new Error("No se pudo conectar con la API. Revisa la conexión y, si aparece CORS, autoriza localhost en la configuración de la API.");
  }
  const json = await respuesta.json().catch(() => ({}));
  if (!respuesta.ok) {
    const detalle = json.errors?.[0]?.message;
    if (respuesta.status === 401) throw new Error("La API rechazó la clave de acceso (401). Revisa API_KEY.");
    if (respuesta.status === 403) throw new Error("Acceso bloqueado (403). Puede ser una restricción de origen CORS o de la cuenta.");
    if (respuesta.status === 404) throw new Error("No se encontró el país solicitado.");
    if (respuesta.status === 429) throw new Error("Se alcanzó el límite temporal de solicitudes. Espera un momento.");
    throw new Error(detalle || `Error de la API: HTTP ${respuesta.status}.`);
  }
  const lista = json.data?.objects;
  if (!Array.isArray(lista)) throw new Error("La API respondió, pero el formato JSON no es el esperado.");
  return lista.map(normalizarPais);
}
function normalizarPais(p) {
  return {
    name: { common: p.names?.common || "Nombre no disponible", official: p.names?.official || "" },
    cca2: p.codes?.alpha_2 || "",
    cca3: p.codes?.alpha_3 || "",
    region: p.region || "Sin región",
    subregion: p.subregion || "",
    population: p.population || 0,
    capital: (p.capitals || []).map(c => typeof c === "string" ? c : c.name).filter(Boolean),
    languages: Array.isArray(p.languages) ? p.languages.map(l => typeof l === "string" ? l : (l.name || l.name_english || l.native_name)).filter(Boolean) : Object.values(p.languages || {}),
    currencies: p.currencies || {},
    timezones: p.timezones || [],
    continents: p.continents || [],
    area: p.area?.kilometers || 0,
    flags: { png: p.codes?.alpha_2 ? `https://flags.restcountries.com/v5/w640/${p.codes.alpha_2.toLowerCase()}.png` : "", alt: `Bandera de ${p.names?.common || "país"}` }
  };
}
async function buscarPais(nombre) {
  return solicitar(`${API}/name?q=${encodeURIComponent(nombre)}`);
}
async function buscarRegion(region) {
  return solicitar(`${API}?region=${encodeURIComponent(region)}`);
}
function escaparHTML(valor) {
  return String(valor ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}
function capital(pais) { return pais.capital?.[0] || "Sin capital"; }
function numero(n) { return Number(n || 0).toLocaleString("es-MX"); }

function renderizarPaises(lista) {
  const region = regionSelect.value;
  let filtrados = lista.filter(p => !region || p.region === region);
  const orden = sortSelect.value;
  if (orden === "population-desc") filtrados.sort((a,b) => b.population - a.population);
  else if (orden === "population-asc") filtrados.sort((a,b) => a.population - b.population);
  else filtrados.sort((a,b) => a.name.common.localeCompare(b.name.common, "es"));
  resultados.innerHTML = "";
  resultCount.textContent = `${filtrados.length} PAÍS(ES)`;
  if (!filtrados.length) {
    resultados.innerHTML = '<div class="empty-state">No hay países que coincidan con este filtro.</div>';
    return;
  }
  filtrados.forEach((pais, index) => {
    const card = document.createElement("article");
    card.className = "country-card"; card.tabIndex = 0; card.setAttribute("role", "button");
    card.setAttribute("aria-label", `Ver detalles de ${pais.name.common}`);
    card.innerHTML = `
      <div class="flag-wrap"><img src="${escaparHTML(pais.flags.png)}" alt="Bandera de ${escaparHTML(pais.name.common)}" loading="lazy"><span class="card-number">${String(index+1).padStart(2,"0")} / ${escaparHTML(pais.cca3)}</span></div>
      <div class="card-body"><span class="card-region">${escaparHTML(pais.region)}</span><h3>${escaparHTML(pais.name.common)}</h3>
      <div class="card-meta"><div><span class="meta-label">CAPITAL</span><span class="meta-value">${escaparHTML(capital(pais))}</span></div>
      <div><span class="meta-label">POBLACIÓN</span><span class="meta-value">${numero(pais.population)}</span></div></div>
      <div class="card-foot"><span>DESCUBRIR PAÍS</span><span>↗</span></div></div>`;
    card.addEventListener("click", () => mostrarDetalle(pais));
    card.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); mostrarDetalle(pais); } });
    resultados.appendChild(card);
  });
}
function mostrarDetalle(pais) {
  const idiomas = pais.languages?.length ? pais.languages.join(", ") : "No disponible";
  const monedas = pais.currencies ? Object.values(pais.currencies).map(m => typeof m === "string" ? m : `${m.name || m.code || "Moneda"}${m.symbol ? ` (${m.symbol})` : ""}`).join(", ") : "No disponible";
  const zona = pais.timezones?.join(", ") || "No disponible";
  const mapa = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(pais.name.common)}`;
  modalContent.innerHTML = `
    <img class="modal-flag" src="${escaparHTML(pais.flags.png)}" alt="Bandera de ${escaparHTML(pais.name.common)}">
    <h2 class="modal-title" id="modalTitle">${escaparHTML(pais.name.common)}</h2>
    <p class="modal-sub">${escaparHTML(pais.name.official)} · ${escaparHTML(pais.cca3)}</p>
    <div class="detail-grid">
      <div class="detail-item"><small>CAPITAL</small><span>${escaparHTML(capital(pais))}</span></div>
      <div class="detail-item"><small>REGIÓN / SUBREGIÓN</small><span>${escaparHTML(pais.region)} / ${escaparHTML(pais.subregion || "—")}</span></div>
      <div class="detail-item"><small>POBLACIÓN</small><span>${numero(pais.population)} habitantes</span></div>
      <div class="detail-item"><small>SUPERFICIE</small><span>${numero(pais.area)} km²</span></div>
      <div class="detail-item"><small>IDIOMAS</small><span>${escaparHTML(idiomas)}</span></div>
      <div class="detail-item"><small>MONEDA(S)</small><span>${escaparHTML(monedas)}</span></div>
      <div class="detail-item"><small>ZONAS HORARIAS</small><span>${escaparHTML(zona)}</span></div>
      <div class="detail-item"><small>CONTINENTE</small><span>${escaparHTML(pais.continents.join(", ") || "—")}</span></div>
    </div><p style="margin:20px 0 0"><a class="explore-link" href="${mapa}" target="_blank" rel="noopener">VER EN GOOGLE MAPS ↗</a></p>`;
  modal.classList.add("open"); modal.setAttribute("aria-hidden", "false"); document.body.style.overflow = "hidden";
}
function cerrarModal() { modal.classList.remove("open"); modal.setAttribute("aria-hidden", "true"); document.body.style.overflow = ""; }
document.getElementById("closeModal").addEventListener("click", cerrarModal);
modal.addEventListener("click", e => { if (e.target.dataset.close) cerrarModal(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") cerrarModal(); });

form.addEventListener("submit", async e => {
  e.preventDefault(); const nombre = input.value.trim();
  if (!nombre) { setMensaje("Escribe el nombre de un país para buscar.", "error"); input.focus(); return; }
  setMensaje(""); resultados.innerHTML = '<div class="loading"><span class="spinner"></span> CONSULTANDO EL DIRECTORIO GLOBAL...</div>'; resultCount.textContent = "CARGANDO";
  try {
    paisesActuales = await buscarPais(nombre); renderizarPaises(paisesActuales);
    setMensaje(`Exploración lista: ${paisesActuales.length} resultado(s) para “${nombre}”.`, "success");
  } catch (error) { resultados.innerHTML = ""; resultCount.textContent = "0 PAÍSES"; setMensaje(error.message, "error"); }
});
regionSelect.addEventListener("change", async () => {
  if (!regionSelect.value) { if (paisesActuales.length) renderizarPaises(paisesActuales); else { resultados.innerHTML = ""; resultCount.textContent = "ESPERANDO BÚSQUEDA"; } return; }
  setMensaje(`Cargando países de ${regionSelect.options[regionSelect.selectedIndex].text}...`);
  resultados.innerHTML = '<div class="loading"><span class="spinner"></span> EXPLORANDO REGIÓN...</div>';
  try { paisesActuales = await buscarRegion(regionSelect.value); renderizarPaises(paisesActuales); setMensaje("Región cargada correctamente.", "success"); }
  catch (error) { resultados.innerHTML = ""; setMensaje(error.message, "error"); }
});
sortSelect.addEventListener("change", () => { if (paisesActuales.length) renderizarPaises(paisesActuales); });
clearButton.addEventListener("click", () => {
  input.value = ""; regionSelect.value = ""; sortSelect.value = "name"; paisesActuales = [];
  resultados.innerHTML = ""; resultCount.textContent = "ESPERANDO BÚSQUEDA";
  setMensaje("Filtros limpiados. Escribe un país para comenzar tu exploración."); input.focus();
});
